# JARVIS C75 Lite — GitHub Actions

Этот архив подготовлен для сборки APK через GitHub Actions без ПК.

## Как собрать с телефона

1. Создай новый GitHub repository.
2. Загрузи содержимое этого проекта в репозиторий.
3. Открой вкладку Actions.
4. Выбери `Build JARVIS C75 APK`.
5. Нажми `Run workflow`.
6. Дождись зелёной галочки.
7. Открой завершённый workflow и скачай artifact `JARVIS-C75-Lite-APK`.
8. Распакуй artifact и установи APK на realme C75.

Workflow использует GitHub-hosted runner и Gradle/Android SDK на сервере GitHub.

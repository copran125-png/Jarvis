package com.example.jarvis

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInferenceSession
import java.io.File

/** C75 Lite: deliberately small generation settings to reduce RAM/heat/battery use. */
class LocalAi(private val context: Context) {
    private var llm: LlmInference? = null
    private var session: LlmInferenceSession? = null

    fun load(modelFile: File) {
        close()
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(modelFile.absolutePath)
            .setMaxTokens(256)
            .setTopK(20)
            .setTopP(0.85f)
            .setTemperature(0.15f)
            .build()
        llm = LlmInference.createFromOptions(context, options)
        val sessionOptions = LlmInferenceSession.LlmInferenceSessionOptions.builder()
            .setTopK(20)
            .setTopP(0.85f)
            .setTemperature(0.15f)
            .build()
        session = LlmInferenceSession.createFromOptions(llm!!, sessionOptions)
    }

    fun isLoaded(): Boolean = session != null

    fun ask(userText: String): String {
        val s = session ?: return "{\"type\":\"say\",\"text\":\"Локальная модель ещё не загружена.\"}"
        val prompt = """
Ты — JARVIS для Android realme C75. Отвечай ОДНИМ JSON без Markdown.
Для действия: {"type":"actions","actions":[...],"say":"..."}
Для разговора: {"type":"say","text":"..."}
Разрешены действия: open_app(app), music(command), volume(value), alarm(hour,minute), open(target).
app: youtube, spotify, telegram, whatsapp, chrome.
command: play, pause, next, previous. target: camera, browser, phone, email, settings, wifi, bluetooth.
volume: 0..100. Не выдумывай другие действия. Ответ делай коротким.
Пользователь: $userText
""".trimIndent()
        s.addQueryChunk(prompt)
        return s.generateResponse()
    }

    fun close() {
        try { session?.close() } catch (_: Exception) {}
        session = null
        try { llm?.close() } catch (_: Exception) {}
        llm = null
    }
}

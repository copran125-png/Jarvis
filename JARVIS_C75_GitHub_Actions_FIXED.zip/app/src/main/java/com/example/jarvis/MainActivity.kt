package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var conversation: TextView
    private lateinit var modelStatus: TextView
    private lateinit var talk: Button
    private lateinit var wake: Button
    private lateinit var tts: TextToSpeech
    private val ai by lazy { LocalAi(this) }
    private var recognizer: SpeechRecognizer? = null
    private var wakeMode = false
    private val audio by lazy { getSystemService(AUDIO_SERVICE) as AudioManager }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContentView(R.layout.activity_main)
        status=findViewById(R.id.status); conversation=findViewById(R.id.conversation); modelStatus=findViewById(R.id.modelStatus)
        talk=findViewById(R.id.talk); wake=findViewById(R.id.wake); tts=TextToSpeech(this,this)
        if (ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),10)
        findViewById<Button>(R.id.loadModel).setOnClickListener { chooseModel() }
        talk.setOnClickListener { listen(false) }
        wake.setOnClickListener { wakeMode=!wakeMode; wake.text=if(wakeMode) "◉ ОЖИДАНИЕ ВКЛЮЧЕНО" else "◉ РЕЖИМ ОЖИДАНИЯ"; if(wakeMode) listen(true) else recognizer?.cancel() }
        status.text="C75 LITE • ГОТОВ"
        modelStatus.text="ИИ: не загружен • быстрые команды работают без ИИ"
    }

    private fun chooseModel(){
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="*/*"; addCategory(Intent.CATEGORY_OPENABLE) },50)
    }
    override fun onActivityResult(req:Int,res:Int,data:Intent?){
        super.onActivityResult(req,res,data); if(req!=50||res!=RESULT_OK)return
        val uri=data?.data?:return
        Thread { try {
            val f=File(filesDir,"jarvis_model.task")
            contentResolver.openInputStream(uri)!!.use { input-> FileOutputStream(f).use { out->input.copyTo(out) } }
            ai.load(f); runOnUiThread { modelStatus.text="ИИ: локальная модель активна • C75 Lite"; say("Локальный интеллект активирован.") }
        } catch(e:Exception){ runOnUiThread { modelStatus.text="ИИ: модель не загрузилась"; say("Не удалось загрузить модель. Быстрые команды всё равно доступны.") } } }.start()
    }

    private fun listen(waitForWake:Boolean){
        if(!SpeechRecognizer.isRecognitionAvailable(this)){say("Распознавание речи недоступно.");return}
        recognizer?.destroy(); recognizer=SpeechRecognizer.createSpeechRecognizer(this)
        recognizer!!.setRecognitionListener(object:RecognitionListener{
            override fun onReadyForSpeech(p:Bundle?){status.text=if(waitForWake)"ОЖИДАЮ «ДЖАРВИС»..." else "СЛУШАЮ..."}
            override fun onResults(r:Bundle?){
                val text=r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if(waitForWake){
                    val l=text.lowercase(Locale.getDefault())
                    if(!l.contains("джарвис")&&!l.contains("jarvis")){if(wakeMode)listen(true);return}
                    val cmd=l.replace("джарвис","").replace("jarvis","").trim()
                    if(cmd.isEmpty()){say("Слушаю.");listen(false)} else process(cmd)
                } else process(text)
            }
            override fun onError(e:Int){if(wakeMode&&waitForWake)listen(true) else status.text="ГОТОВ"}
            override fun onBeginningOfSpeech(){}; override fun onRmsChanged(v:Float){}; override fun onBufferReceived(b:ByteArray?){}; override fun onEndOfSpeech(){}; override fun onPartialResults(b:Bundle?){}; override fun onEvent(t:Int,b:Bundle?){}
        })
        recognizer!!.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ru-RU"); putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3)
        })
    }

    private fun process(raw:String){
        val text=raw.trim(); if(text.isEmpty())return
        conversation.text="Вы: $text"
        // C75 Lite fast path: no LLM for common commands.
        if(handleFastCommand(text.lowercase(Locale.getDefault()))) { status.text="ГОТОВ"; return }
        if(!ai.isLoaded()){ status.text="ГОТОВ"; say("Я понял не всё. Загрузите лёгкую локальную модель для свободного диалога."); return }
        status.text="ИИ ДУМАЕТ..."
        Thread { try { val out=ai.ask(text); runOnUiThread{handleAi(out)} } catch(_:Exception){runOnUiThread{status.text="ГОТОВ";say("Ошибка локального ИИ.")}} }.start()
    }

    private fun handleFastCommand(c:String):Boolean {
        var did=false
        fun has(vararg s:String)=s.any{c.contains(it)}
        if(has("камеру","камера")){openTarget("camera");say("Открываю камеру.");did=true}
        if(has("телеграм","telegram")){openApp("telegram");say("Открываю Telegram.");did=true}
        else if(has("ватсап","whatsapp")){openApp("whatsapp");say("Открываю WhatsApp.");did=true}
        else if(has("спотифай","spotify")){openApp("spotify");say("Открываю Spotify.");did=true}
        else if(has("ютуб","youtube")){openApp("youtube");say("Открываю YouTube.");did=true}
        else if(has("хром","chrome","браузер")){openApp("chrome");say("Открываю браузер.");did=true}
        if(has("следующ", "следующий трек")){media(android.view.KeyEvent.KEYCODE_MEDIA_NEXT);say("Переключаю.");did=true}
        if(has("предыдущ", "предыдущий трек")){media(android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS);say("Переключаю назад.");did=true}
        if(has("пауза","поставь на паузу")){media(android.view.KeyEvent.KEYCODE_MEDIA_PAUSE);say("Пауза.");did=true}
        if(has("продолжи","включи музыку","воспроизведи музыку","запусти музыку")){media(android.view.KeyEvent.KEYCODE_MEDIA_PLAY);say("Воспроизвожу.");did=true}
        if(has("громче")){audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_RAISE,AudioManager.FLAG_SHOW_UI);did=true}
        if(has("тише")){audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_LOWER,AudioManager.FLAG_SHOW_UI);did=true}
        Regex("(?:громкость|звук)\\s*(?:на\\s*)?(\\d{1,3})").find(c)?.groupValues?.getOrNull(1)?.toIntOrNull()?.let{setVolume(it);say("Громкость $it процентов.");did=true}
        if(has("настройки","настройки телефона")){openTarget("settings");say("Открываю настройки.");did=true}
        if(has("wi-fi","вай фай","вайфай")){openTarget("wifi");say("Открываю Wi-Fi.");did=true}
        if(has("bluetooth","блютуз")){openTarget("bluetooth");say("Открываю Bluetooth.");did=true}
        if(has("позвонить","телефон")){openTarget("phone");did=true}
        if(has("почту","email","электронную почту")){openTarget("email");did=true}
        if(c.contains("будильник")){
            val m=Regex("(\\d{1,2})\\s*(?:час|ч|:)[\\s:]*([0-5]\\d)?").find(c)
            val h=m?.groupValues?.getOrNull(1)?.toIntOrNull(); val min=m?.groupValues?.getOrNull(2)?.toIntOrNull()?:0
            if(h!=null&&h in 0..23){setAlarm(h,min);say("Будильник на %02d:%02d.".format(h,min));did=true}
        }
        return did
    }

    private fun handleAi(raw:String){
        try{
            val a=raw.indexOf('{'); val b=raw.lastIndexOf('}'); val j=JSONObject(raw.substring(a,b+1))
            if(j.optString("type")=="say") say(j.optString("text","Готово.")) else { val arr=j.optJSONArray("actions"); if(arr!=null) for(i in 0 until arr.length()) executeAction(arr.getJSONObject(i)); say(j.optString("say","Готово.")) }
        }catch(_:Exception){say(raw.take(300))}
        status.text="ГОТОВ"
    }
    private fun executeAction(a:JSONObject){when(a.optString("action")){
        "open_app"->openApp(a.optString("app")); "music"->when(a.optString("command")){"play"->media(126),"pause"->media(127),"next"->media(87),"previous"->media(88)};
        "volume"->setVolume(a.optInt("value",50)); "alarm"->setAlarm(a.optInt("hour",8),a.optInt("minute",0)); "open","settings"->openTarget(a.optString("target"))
    }}

    private fun openApp(name:String){
        val packages=mapOf("youtube" to "com.google.android.youtube","spotify" to "com.spotify.music","telegram" to "org.telegram.messenger","whatsapp" to "com.whatsapp","chrome" to "com.android.chrome")
        val p=packages[name]; val i=p?.let{packageManager.getLaunchIntentForPackage(it)}
        if(i!=null)startActivity(i) else say("Это приложение не установлено.")
    }
    private fun openTarget(t:String){when(t){"camera"->startActivity(Intent("android.media.action.IMAGE_CAPTURE"));"browser"->startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com")));"phone"->startActivity(Intent(Intent.ACTION_DIAL));"email"->startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_EMAIL));"settings"->startActivity(Intent(Settings.ACTION_SETTINGS));"wifi"->startActivity(Intent(Settings.ACTION_WIFI_SETTINGS));"bluetooth"->startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))}}
    private fun media(code:Int){sendBroadcast(Intent(Intent.ACTION_MEDIA_BUTTON).putExtra(Intent.EXTRA_KEY_EVENT,android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN,code)));sendBroadcast(Intent(Intent.ACTION_MEDIA_BUTTON).putExtra(Intent.EXTRA_KEY_EVENT,android.view.KeyEvent(android.view.KeyEvent.ACTION_UP,code)))}
    private fun setVolume(percent:Int){val max=audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);audio.setStreamVolume(AudioManager.STREAM_MUSIC,(max*percent.coerceIn(0,100)/100f).toInt(),AudioManager.FLAG_SHOW_UI)}
    private fun setAlarm(h:Int,m:Int){startActivity(Intent(AlarmClock.ACTION_SET_ALARM).apply{putExtra(AlarmClock.EXTRA_HOUR,h);putExtra(AlarmClock.EXTRA_MINUTES,m);putExtra(AlarmClock.EXTRA_SKIP_UI,false)})}
    private fun say(text:String){conversation.append("\nJARVIS: $text"); if(::tts.isInitialized)tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"jarvis") }
    override fun onInit(status:Int){if(status==TextToSpeech.SUCCESS){tts.language=Locale("ru","RU")}}
    override fun onDestroy(){wakeMode=false;recognizer?.destroy();tts.stop();tts.shutdown();ai.close();super.onDestroy()}
}
